clear
close all
load('heart_dat.mat'); % load myo layer
load('heart_dat2.mat'); % load myo fyber
load('M_R_1.mat'); % load transfer matrix
TT = [1 0 0;0 0 -1;0 1 0];

%% Cardiac structure data preprocessing
[zero,judge,judge_in,judge_in_left,judge_in_right,judge_mid,judge_out,judge_pky,judge_pky_left,judge_pky_right,judge_p,length_x,length_y,length_z ] = ...
    Streamlining( judge,judge_in,judge_in_left,judge_in_right,judge_mid,judge_out,judge_pky,judge_pky_left,judge_pky_right,judge_p );

p = zeros(length_x,length_y,length_z,6);
judge_zero = zeros(length_x,length_y,length_z);
act_zone = zeros(length_x,length_y,length_z);


%% ECG simulation

plot_act_left = [38,38,63];
act_zone(plot_act_left(1),plot_act_left(2),plot_act_left(3)) = 1;

p(:,:,:,1) = judge_p(:,:,:,1);
p(:,:,:,2) = judge_p(:,:,:,1);
p(:,:,:,3) = judge_p(:,:,:,2);
p(:,:,:,4) = judge_p(:,:,:,2);
p(:,:,:,5) = judge_p(:,:,:,3);
p(:,:,:,6) = judge_p(:,:,:,3);
p = 0.65*sqrt(p);

test_k = [];
weiyi = round( normrnd(-260,20,[30,1]));


k_rand = 1.2;
k_rand_str = 'nor_p1.2';
for data_num =1:1
    str = [num2str(data_num) '__p' num2str(k_rand) ];
    judge_ill = judge_zero;
    p_temp = (k_rand-2*(k_rand-1)*rand(1)) * p;
    
    tic
    [VCG_all,test_mem,test_k_temp] = ventricle3D_layer5_eff( act_zone,judge,judge_in,judge_mid,judge_out,judge_pky,judge_pky_left,p_temp , judge_ill,k_rand);
    toc
    
    VCG = ECG_adjust2(VCG_all(1:3,:));
    VCG2 = myrotate(VCG',[10*rand(1)-5-20 10*rand(1)-5-20 40*rand(1)-20+40 1 0 0],[0,0,0]);
    VCG2 = VCG2';
    VCG2 = VCG2 + (VCG2==0) .* eps;
    ECG_Regress = M_R' * (TT * VCG2);
    ECG_Regress = ECG_adjust3(ECG_Regress);
    
    ECG_out = Pwave_add(ECG_Regress) .* [ repmat(1.1-0.2*rand(1),6,1) ; (1-0.2*rand(6,1))];
    ECG_out = 0.01* ECG_adjust(ECG_out(:,:),weiyi(data_num));

    figure
    for i=1:12
        subplot(6,2,i)
        plot(1:800,ECG_out(i,:),'k','LineWidth',2);
    end
        
%     test_k = [test_k;test_k_temp];
    
end
