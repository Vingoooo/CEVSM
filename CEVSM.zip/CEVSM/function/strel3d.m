function [se,n,rx,ry,rz] = strel3d(r)

% user r
if length(r)<2
    rx = r;
    ry = r;
    rz = r;
elseif length(r)>2
    rx = r(1);
    ry = r(2);
    rz = r(3);
else
    rx = r(1);
    ry = r(1);
    rz = r(2);
end

% 
[x,y,z] = meshgrid(-rx:rx,-ry:ry,-rz:rz);
[x,y,z] = find3d(sqrt(x.^2+y.^2+z.^2)<(rx+ry+rz)/2.5); %
se = [x-rx-1,y-ry-1,z-rz-1];

n = size(se,1);

end