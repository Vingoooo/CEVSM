function ball_spot = xyz2ball(xyz_spot,zero_spot)
[len,~] = size(xyz_spot);
zero_spot = repmat(zero_spot,len,1);
xyz_spot2 = xyz_spot - zero_spot;

idL = find(xyz_spot2(:,1) < 0);
sign = ones(len,1);
sign(idL) = -1;
r_spot = sqrt(sum(xyz_spot2.*xyz_spot2,2)) .* sign ;

% theta_spot = atan(xyz_spot2(:,2)./xyz_spot2(:,1)) .* (sign(xyz_spot2(:,1)) == 1) +...
%     (  pi - atan(xyz_spot2(:,2)./xyz_spot2(:,1))) .* (sign(xyz_spot2(:,1)) ~= 1);
theta_spot = atan(xyz_spot2(:,2)./xyz_spot2(:,1));

theta_spot(isnan(theta_spot))=0;

phi_spot = acos(xyz_spot2(:,3)./r_spot);
phi_spot(isnan(phi_spot))=0;
ball_spot = [r_spot,theta_spot,phi_spot];

end


