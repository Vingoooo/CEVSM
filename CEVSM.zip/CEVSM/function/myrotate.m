function xyz_spot2 = myrotate(xyz_spot,p_rotate,zero_spot)
% rotate
zero_spot0 = zero_spot;
[len,~] = size(xyz_spot);
theta_xy0 = p_rotate(1);
theta_xz0 = p_rotate(2);
theta_yz0 = p_rotate(3);
theta_xy = theta_xy0 * pi/180;
theta_xz = theta_xz0 * pi/180;
theta_yz = theta_yz0 * pi/180;

A1 = [cos(theta_xy) sin(theta_xy) 0;
    -sin(theta_xy) cos(theta_xy) 0;
    0 0 1];

A2 = [cos(theta_xz) 0 sin(theta_xz);
    0 1 0;
    -sin(theta_xz) 0  cos(theta_xz)];

A3 = [1 0 0;
    0 cos(theta_yz) sin(theta_yz);
    0 -sin(theta_yz) cos(theta_yz)];

r_t = p_rotate(4);
theta_t0 = p_rotate(5);
phi_t0 = p_rotate(6);
theta_t = theta_t0 * pi/180;
phi_t = phi_t0 * pi/180;


ball_spot = xyz2ball(xyz_spot,zero_spot);
zero_spot = repmat(zero_spot,len,1);

temp = r_t .* ball_spot(:,1) .*[sin(ball_spot(:,3)+phi_t).*cos(ball_spot(:,2)+theta_t) ,sin(ball_spot(:,3)+phi_t).*sin(ball_spot(:,2)+theta_t) , cos(ball_spot(:,3)+phi_t)] +zero_spot;

xyz_spot2 = (A3*A2*A1*(temp - zero_spot)' + zero_spot')';

end

