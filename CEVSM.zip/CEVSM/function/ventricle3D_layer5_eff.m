function [VCG ,test_mem ,test_k] = ...
    ventricle3D_layer5_eff( act_zone,judge ,judge_in,judge_mid,judge_out,judge_pky,judge_pky_left,p , judge_ill,k_rand)

load('heart_dat3.mat');

test_k = zeros(1,3);

length_x = size(judge,1);
length_y = size(judge,2);
length_z = size(judge,3);



%% Main event loop
stop= 0; %wait for a quit button push

zero_e = zeros(length_x+2,length_y+2,length_z+2);
temp = zero_e;
temp(2:end-1,2:end-1,2:end-1) = judge_ill(:,:,:);
judge_ill = temp;

%% judge_ill =3 
temp(2:end-1,2:end-1,2:end-1) = judge(:,:,:);
judge = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_in(:,:,:);
judge_in = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_mid(:,:,:);
judge_mid = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_out(:,:,:);
judge_out = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = act_zone(:,:,:);
act_zone = temp ;

%% pky no infarction
temp(2:end-1,2:end-1,2:end-1) = judge_pky(:,:,:);
judge_ill_temp = dilate3d(judge_ill==3,1);  % 1
% judge_pky = temp .* (~judge_ill_temp) ;
judge_pky = temp ;
temp(2:end-1,2:end-1,2:end-1) = judge_pky_left(:,:,:);
% judge_pky_left = temp .* (~judge_ill_temp) ;
judge_pky_left = temp ;


zero = zero_e; % 

cell_position_VM = judge;
cell_ventricle = judge;


%% 'judge_subendo','judge_myomid_i','judge_myomid_o','judge_epi_i','judge_epi_m','judge_epi_o'

temp(2:end-1,2:end-1,2:end-1) = judge_epi_i(:,:,:);
judge_epi_i = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_epi_o(:,:,:);
judge_epi_o = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_myomid_i(:,:,:);
judge_myomid_i = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_myomid_o(:,:,:);
judge_myomid_o = temp .* (judge_ill~=3) ;
temp(2:end-1,2:end-1,2:end-1) = judge_subendo(:,:,:);
judge_subendo = temp .* (judge_ill~=3) ;

cell_ventricle_out_1 = judge_epi_i;
cell_ventricle_out_2 = judge_epi_o;
cell_ventricle_mid_1 = judge_myomid_i;
cell_ventricle_mid_2 = judge_myomid_o;
cell_ventricle_in = judge_subendo;

status_ventricle = zero;
status_ventricle_last = zero;
status_ventricle_out_1 = zero;
status_ventricle_out_2 = zero;
status_ventricle_mid_1 = zero;
status_ventricle_mid_2 = zero;
status_ventricle_in = zero;


cell_potential_V = zero;

test_mem = zeros(length_x,length_y,length_z,320);% mid results

cells = act_zone;

%% ap
if k_rand ==1
    zoom_k = [26/28 87.5/90;0.9 1;0.9 1];
    value_ap = ap_set_5(1,[1 0.81 0.69 0.61 0.81],zoom_k,600);
else
    zoom_k = [26/28 87.5/90;0.9 1;0.9 1] * (k_rand-2*(k_rand-1)*rand(1));
    value_ap = ap_set_5(1,[1 0.81 0.69 0.61 0.81].* (0.8-2*(k_rand-1)*rand(1)),zoom_k,600); %
end

% figure
% hold on
for mm = 1:20
    if k_rand ==1
        value_ap(mm,:) = APsmooth(value_ap(mm,:),20);
    else
        value_ap(mm,:) = APsmooth(value_ap(mm,:),15+unidrnd(5));
    end
    %     plot(value_ap(mm,:));
end

value_ventricle_out_1 = value_ap(1,:);
value_ventricle_out_2 = value_ap(2,:);
value_ventricle_out_ill_1_1 = value_ap(3,:);
value_ventricle_out_ill_1_2 = value_ap(4,:);
value_ventricle_out_ill_2_1 = value_ap(5,:);
value_ventricle_out_ill_2_2 = value_ap(6,:);
value_ventricle_out_ill_3_1 = value_ap(7,:);
value_ventricle_out_ill_3_2 = value_ap(8,:);

value_ventricle_mid_1 = value_ap(9,:);
value_ventricle_mid_2 = value_ap(10,:);
value_ventricle_mid_ill_1_1 = value_ap(11,:);
value_ventricle_mid_ill_1_2 = value_ap(12,:);
value_ventricle_mid_ill_2_1 = value_ap(13,:);
value_ventricle_mid_ill_2_2 = value_ap(14,:);
value_ventricle_mid_ill_3_1 = value_ap(15,:);
value_ventricle_mid_ill_3_2 = value_ap(16,:);

value_ventricle_in = value_ap(17,:);
value_ventricle_in_ill_1 = value_ap(18,:);
value_ventricle_in_ill_2 = value_ap(19,:);
value_ventricle_in_ill_3 = value_ap(20,:);

%%



aclen = 600;
%
% figure
% hold on
% plot(value_ventricle_in,'LineWidth',3);
% plot(value_ventricle_mid_2,'LineWidth',3);
% plot(value_ventricle_out_2,'LineWidth',3);
% legend('in','mid','out');
% APD80(value_ventricle_in)

%% CA wroking

r_V = 1;
%index definition for cell update

xV = r_V+1:length_x+r_V;
yV = r_V+1:length_y+r_V;
zV = r_V+1:length_z+r_V;
cells_VM = zero;
cells_VM_site = zero;
status_cells_VM = zero;
cells_VM_area = judge;


cells_PKY_n = ~judge_pky | act_zone;
cells_PKY_site = zero;
cells_PKY_area = judge_pky |act_zone;


VCG_Vx = zeros(1,800);
VCG_Vy = zeros(1,800);
VCG_Vz = zeros(1,800);


run = 1;%test use


actived_flag = 0;


cell_ventricle_6v = zeros(length_x+2,length_y+2,length_z+2);
cell_ventricle_6v(:,:,:) = cell_ventricle(:,:,:);

base_x(1:3,1:3,1) = zeros(3,3,1);
base_x(1:3,1:3,2) = [0 1 0;0 0 0 ;0 -1 0];
base_x(1:3,1:3,3) = zeros(3,3,1);

base_y(1:3,1:3,1) = zeros(3,3,1);
base_y(1:3,1:3,2) = [0 0 0;1 0 -1;0 0 0];
base_y(1:3,1:3,3) = zeros(3,3,1);

base_z(1:3,1:3,1) = [0 0 0;0 1 0;0 0 0];
base_z(1:3,1:3,2) = zeros(3,3,1);
base_z(1:3,1:3,3) = [0 0 0;0 -1 0;0 0 0];



act_V_1 = 2;% Depolarization speed, propagation diameter of depolarization for each simulation step
act_V_2 = 1;
step_v = 0.8* (k_rand-2*(k_rand-1)*rand(1)); % State switching rate, i.e. how much myocardial cell state switches per simulation step

act_PKY = 3; % pky 3 steps/ms
act_VM = 1;  % myo 1 step/ms
p_over_pky = 0.8;  % 0.99
p_over_vm_m = 0.2;% * (k_rand-2*(k_rand-1)*rand(1)); %

p_over_vm = 0.99;
pky_over = 0;
vm_over = 0;

rand_pky = 0.8*(k_rand-2*(k_rand-1)*rand(1)); %
% rand_pky = 1;

stepnumber = 1;
while ( stop==0 && stepnumber<800)  %800
    if(mod(stepnumber,50)==0 )
        disp(['Progress time:',num2str(stepnumber),'ms',])
    end
    %     if(mod(stepnumber,10)==0 )
    if(stepnumber<320) % 600
        test_mem(:,:,:,stepnumber) = status_ventricle(2:end-1,2:end-1,2:end-1);
        %         test_mem(:,:,:,stepnumber/10+160) = cells_PKY_site(2:end-1,2:end-1,2:end-1);
    end
    
    if (stepnumber>=100 && actived_flag==0)
        disp(['The excitement begin:',num2str(stepnumber),'ms',])
        cells_VM = cells .* cells_VM_area;
        cells_VM_site = cells  .* cells_VM_area;
        status_cells_VM = cells .* cells_VM_area;
        cells_PKY_site = cells;
        actived_flag = 1;
    end
    if (run==1)
        % neighbor judge for VM
        if (actived_flag == 1)
            %         if (1)
            if ( vm_over == 0 && pky_over < 2) % At the beginning, excitement spreads in the interventricular septum, mainly longitudinally, along the atrioventricular tract
                for t =1:act_V_1
                    rand1 = (rand(length_x,length_y,length_z)  < p(:,:,:,1));
                    rand2 = (rand(length_x,length_y,length_z)  < p(:,:,:,2));
                    rand3 = (rand(length_x,length_y,length_z)  < 0.1+0.9*p(:,:,:,3));
                    rand4 = (rand(length_x,length_y,length_z)  < p(:,:,:,4));
                    rand5 = (rand(length_x,length_y,length_z)  < 0.5*p(:,:,:,5));
                    rand6 = (rand(length_x,length_y,length_z)  < 0.5*p(:,:,:,6));
                    neighbor_judge = (rand1&(cells_VM_site(xV+1,yV,zV)) |...
                        (rand2&cells_VM_site(xV-1,yV,zV)) |...
                        (rand3&cells_VM_site(xV,yV+1,zV)) |...
                        (rand4&cells_VM_site(xV,yV-1,zV)) |...
                        (rand5&cells_VM_site(xV,yV,zV+1)) |...
                        (rand6&cells_VM_site(xV,yV,zV-1)));% 
                    cells_VM_site(xV,yV,zV) =( neighbor_judge | cells_VM_site(xV,yV,zV) ) & cells_VM_area(xV,yV,zV); % new activated cells
                    if pky_over >=1 % Early excitement is not directly transmitted by the atrioventricular bundle, wait for the atrioventricular bundle to basically end and enter pky before starting
                        %                     if 1
                        cells_VM_site(xV,yV,zV) = ( cells_PKY_site(xV,yV,zV) & (rand(length_x,length_y,length_z)  <0.3) ) | cells_VM_site(xV,yV,zV);
                        %                         cells_VM_site(xV,yV,zV) = ( cells_PKY_site(xV,yV,zV) | cells_VM_site(xV,yV,zV) ) & (rand(length_x,length_y,length_z)  <0.3);
                        %                         pky_over = 1.1;
                    end
                    cells_VM(xV,yV,zV) = cells_VM_site(xV,yV,zV) & cell_position_VM(xV,yV,zV);
                end
                
                %                 if ( sum(sum(sum(cells_VM_site))) >p_over_vm_m * sum(sum(sum(cells_VM_area))))
                %                     vm_over = 0.1;
                %                     disp(['VM interval wall excitement over:',num2str(stepnumber),'ms',])
                %                     test_k(1) = stepnumber;
                %                 end
            end
            
            if (vm_over > 0 && vm_over ~= 1  && mod(stepnumber,act_VM)==0) % myo mode
                for t =1:act_V_2
                    rand1 = (rand(length_x,length_y,length_z)  < p(:,:,:,1));
                    rand2 = (rand(length_x,length_y,length_z)  < p(:,:,:,2));
                    rand3 = (rand(length_x,length_y,length_z)  < p(:,:,:,3));
                    rand4 = (rand(length_x,length_y,length_z)  < p(:,:,:,4));
                    rand5 = (rand(length_x,length_y,length_z)  < p(:,:,:,5));
                    rand6 = (rand(length_x,length_y,length_z)  < p(:,:,:,6));
                    neighbor_judge = (rand1&(cells_VM_site(xV+1,yV,zV)) |...
                        (rand2&cells_VM_site(xV-1,yV,zV)) |...
                        (rand3&cells_VM_site(xV,yV+1,zV)) |...
                        (rand4&cells_VM_site(xV,yV-1,zV)) |...
                        (rand5&cells_VM_site(xV,yV,zV+1)) |...
                        (rand6&cells_VM_site(xV,yV,zV-1)));% 
                    cells_VM_site(xV,yV,zV) =( neighbor_judge | cells_VM_site(xV,yV,zV) ) & cells_VM_area(xV,yV,zV); % new activated cells
                    if pky_over >=1
                        %  cells_VM_site(xV,yV,zV) = ( cells_PKY_site(xV,yV,zV) & (rand(length_x,length_y,length_z)  <0.6) ) | cells_VM_site(xV,yV,zV);
                        cells_VM_site(xV,yV,zV) = ( cells_PKY_site(xV,yV,zV) | cells_VM_site(xV,yV,zV) );
                    end
                    cells_VM(xV,yV,zV) = cells_VM_site(xV,yV,zV) & cell_position_VM(xV,yV,zV);
                end
                if ( sum(sum(sum(cells_VM_site))) >p_over_vm * sum(sum(sum(cells_VM_area))))
                    disp(['VM excitement over:',num2str(stepnumber),'ms',])
                    vm_over = 1;
                    cells_VM_site(xV,yV,zV) = cells_VM_area(xV,yV,zV);
                    cells_VM(xV,yV,zV) = cells_VM_site(xV,yV,zV) & cell_position_VM(xV,yV,zV);
                    test_k(3) = stepnumber;
                end
            end
            % neighbor judge for pky
            if (pky_over < 2)  % 
                for t =1:act_PKY
                    rand3 = (rand(length_x,length_y,length_z)  < rand_pky*sqrt(3)/6) | judge_pky_left(xV,yV,zV); % sqrt(3)/6
                    rand2 = (rand(length_x,length_y,length_z)  < rand_pky*sqrt(2)/4) | judge_pky_left(xV,yV,zV); % sqrt(2)/4
                    rand1 = (rand(length_x,length_y,length_z)  < rand_pky*0.5) | judge_pky_left(xV,yV,zV); % 0.5
                    
                    neighbor_judge = ((rand1&cells_PKY_site(xV+1,yV,zV)) |...
                        (rand1&cells_PKY_site(xV-1,yV,zV)) | ...
                        (rand1&cells_PKY_site(xV,yV+1,zV)) |...
                        (rand1&cells_PKY_site(xV,yV-1,zV)) |...
                        (rand1&cells_PKY_site(xV,yV,zV+1)) |...
                        (rand1&cells_PKY_site(xV,yV,zV-1)) |... %%
                        (rand2&cells_PKY_site(xV,yV-1,zV-1)) |...
                        (rand2&cells_PKY_site(xV,yV-1,zV+1)) |...
                        (rand2&cells_PKY_site(xV,yV+1,zV-1)) |...
                        (rand2&cells_PKY_site(xV,yV+1,zV+1)) |...
                        (rand2&cells_PKY_site(xV-1,yV,zV-1)) |...
                        (rand2&cells_PKY_site(xV-1,yV,zV+1)) |...
                        (rand2&cells_PKY_site(xV+1,yV,zV-1)) |...
                        (rand2&cells_PKY_site(xV+1,yV,zV+1)) |...
                        (rand2&cells_PKY_site(xV-1,yV-1,zV)) |...
                        (rand2&cells_PKY_site(xV-1,yV+1,zV)) |...
                        (rand2&cells_PKY_site(xV+1,yV-1,zV)) |...
                        (rand2&cells_PKY_site(xV+1,yV+1,zV)) |...  %%
                        (rand3&cells_PKY_site(xV-1,yV-1,zV-1)) |...
                        (rand3&cells_PKY_site(xV-1,yV-1,zV+1)) |...
                        (rand3&cells_PKY_site(xV-1,yV+1,zV-1)) |...
                        (rand3&cells_PKY_site(xV-1,yV+1,zV+1)) |...
                        (rand3&cells_PKY_site(xV+1,yV-1,zV-1)) |...
                        (rand3&cells_PKY_site(xV+1,yV-1,zV+1)) |...
                        (rand3&cells_PKY_site(xV+1,yV+1,zV-1)) |...
                        (rand3&cells_PKY_site(xV+1,yV+1,zV+1)) );% 
                    
                    cells_PKY_site(xV,yV,zV) = (neighbor_judge | cells_PKY_site(xV,yV,zV) ) & cells_PKY_area(xV,yV,zV) ; % new activated cells
                    cells_PKY_n(xV,yV,zV) = cells_PKY_site(xV,yV,zV) | ~cells_PKY_area(xV,yV,zV);
                end
                
                if ( sum(sum(sum(cells_PKY_site))) > p_over_pky * sum(sum(sum(cells_PKY_area))))
                    %  if pky_over ==0
                    %  disp(['PKY excitement over:',num2str(stepnumber),'ms',])
                    pky_over = 1;
                    %  end
                    %  cells_PKY_site(xV,yV,zV) = cells_PKY_area(xV,yV,zV);
                    %  cells_PKY_n(xV,yV,zV) = cells_PKY_site(xV,yV,zV) | ~cells_PKY_area(xV,yV,zV);
                    test_k(2) = stepnumber;
                end
                if ( sum(sum(sum(cells_PKY_site))) == sum(sum(sum(cells_PKY_area))))
                    %                     disp(['PKY excitement last:',num2str(stepnumber),'ms',])
                    pky_over = 2;
                    vm_over = 0.1;
                    cells_PKY_site(xV,yV,zV) = cells_PKY_area(xV,yV,zV);
                    cells_PKY_n(xV,yV,zV) = cells_PKY_site(xV,yV,zV) | ~cells_PKY_area(xV,yV,zV);
                end
            end
        end
        
        % The CA rule for VM
        status_cells_VM(xV,yV,zV) = status_cells_VM(xV,yV,zV) + step_v * (cells_VM(xV,yV,zV)>=1);
        status_cells_VM(xV,yV,zV) = status_cells_VM(xV,yV,zV).* (status_cells_VM(xV,yV,zV)<(aclen-2)) + (aclen-2)*(status_cells_VM(xV,yV,zV)>=(aclen-2));
        status_cells_VM(xV,yV,zV) = mod(status_cells_VM(xV,yV,zV),(aclen-1)); % update cells status
        
        status_ventricle(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle(xV,yV,zV));
        
        if (isempty(find((status_ventricle - status_ventricle_last)~=0, 1)) && stepnumber>1 )  % speed up
            
            VCG_Vx(stepnumber) = VCG_Vx(stepnumber-1);
            VCG_Vy(stepnumber) = VCG_Vy(stepnumber-1);
            VCG_Vz(stepnumber) = VCG_Vz(stepnumber-1);
            
            stepnumber = 1 + stepnumber;
            continue;
        else
            status_ventricle_last = status_ventricle;
        end
        
        
        %% potential caculator
        status_ventricle_out_1(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle_out_1(xV,yV,zV));% 
        status_ventricle_out_2(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle_out_2(xV,yV,zV));% 
        status_ventricle_mid_1(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle_mid_1(xV,yV,zV));
        status_ventricle_mid_2(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle_mid_2(xV,yV,zV));
        status_ventricle_in(xV,yV,zV) = fix(status_cells_VM(xV,yV,zV) .* cell_ventricle_in(xV,yV,zV));
        
        cell_potential_V(xV,yV,zV) = ...
            cell_ventricle_out_1(xV,yV,zV) .* (value_ventricle_out_1(status_ventricle_out_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==0) + ...
            value_ventricle_out_ill_1_1(status_ventricle_out_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==1)  + ...  % isc
            value_ventricle_out_ill_2_1(status_ventricle_out_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==2)  + ...  % inj
            value_ventricle_out_ill_3_1(status_ventricle_out_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==3) ) + ... % inf
            cell_ventricle_out_2(xV,yV,zV) .* (value_ventricle_out_2(status_ventricle_out_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==0) + ...
            value_ventricle_out_ill_1_2(status_ventricle_out_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==1)  + ...  % 
            value_ventricle_out_ill_2_2(status_ventricle_out_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==2)  + ...  % 
            value_ventricle_out_ill_3_2(status_ventricle_out_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==3) ) + ... % 
            cell_ventricle_mid_1(xV,yV,zV) .* (value_ventricle_mid_1(status_ventricle_mid_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==0) + ...
            value_ventricle_mid_ill_1_1(status_ventricle_mid_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==1)  + ...
            value_ventricle_mid_ill_2_1(status_ventricle_mid_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==2)  + ...
            value_ventricle_mid_ill_3_1(status_ventricle_mid_1(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==3) ) + ...
            cell_ventricle_mid_2(xV,yV,zV) .* (value_ventricle_mid_2(status_ventricle_mid_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==0) + ...
            value_ventricle_mid_ill_1_2(status_ventricle_mid_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==1)  + ...
            value_ventricle_mid_ill_2_2(status_ventricle_mid_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==2)  + ...
            value_ventricle_mid_ill_3_2(status_ventricle_mid_2(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==3) ) + ...
            cell_ventricle_in(xV,yV,zV) .* (value_ventricle_in(status_ventricle_in(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==0) + ...
            value_ventricle_in_ill_1(status_ventricle_in(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==1)  + ...
            value_ventricle_in_ill_2(status_ventricle_in(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==2)  + ...
            value_ventricle_in_ill_3(status_ventricle_in(xV,yV,zV)+1) .*(judge_ill(xV,yV,zV)==3) );
        
        
        sum_Vx = sum(sum(sum(convn(cell_potential_V,base_x,'same') .* cell_ventricle_6v)));
        sum_Vy = sum(sum(sum(convn(cell_potential_V,base_y,'same') .* cell_ventricle_6v)));
        sum_Vz = sum(sum(sum(convn(cell_potential_V,base_z,'same') .* cell_ventricle_6v)));
        
        VCG_Vx(stepnumber) = sum_Vx;
        VCG_Vy(stepnumber) = sum_Vy;
        VCG_Vz(stepnumber) = sum_Vz;
        stepnumber = 1 + stepnumber;
    end
    VCG = [VCG_Vx;VCG_Vy;VCG_Vz]/100000;
end


end

