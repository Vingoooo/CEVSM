function ECG_out = Pwave_add(ECG_all)

% add p wave

p = 4*normpdf(1:100,50*(1.2-0.4*rand(1)),16*(1.2-0.4*rand(1)));

pk = [68 117 73 -92 -19 92 53 63 73 73 68 63 ]' .*(1.2-0.4*rand(12,1));

ECG_out = ECG_all;
ECG_out(:,1:100) = ECG_all(:,1:100) + repmat( p,12,1) .* pk;
end