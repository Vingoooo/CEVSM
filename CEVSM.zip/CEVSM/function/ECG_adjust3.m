function ECG_p3 = ECG_adjust3(ECG_p)

[~,N] = size(ECG_p);
    begina = ECG_p(:,1);

    ECG_p3 = repmat( begina,1,N);
    ECG_p3 = ECG_p - ECG_p3;

end

