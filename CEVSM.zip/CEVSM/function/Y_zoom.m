function b = Y_zoom(a,k)
b = (a >0).* a.* k(1) + (a <0).* a.* k(2);

%% '%' for plot while no '%' for generation
mt = find(b == max(b));
lenb = length(b);
endb = b(lenb);
temp = ones(1,lenb);
temp(1:lenb-mt+3) = b(mt-2:lenb);
temp(lenb-mt+4:lenb) = endb;
b = temp;

end

