function out = APsmooth(b,k)
maxb = max(b);
temp  = smooth(b,k);
mt = find(temp == max(temp));
leng = length(temp(1) : (max(temp) - temp(1))/(mt-1) :max(temp));
if leng == mt
    temp(1:mt) =  temp(1) : (max(temp) - temp(1))/(mt-1) :max(temp);
elseif leng == mt+1
    temp(1:mt+1) =  temp(1) : (max(temp) - temp(1))/(mt-1) :max(temp);
elseif leng == mt -1
    temp(1:mt-1) =  temp(1) : (max(temp) - temp(1))/(mt-1) :max(temp);
else
end
out = temp;

end

