function [ zero,judge,judge_in,judge_in_left,judge_in_right,judge_mid,judge_out,judge_pky,judge_pky_left,judge_pky_right,judge_p,length_x,length_y,length_z ] = ...
    Streamlining( judge,judge_in,judge_in_left,judge_in_right,judge_mid,judge_out,judge_pky,judge_pky_left,judge_pky_right,judge_p )


[length_x ,length_y  ,length_z] = size(judge);

for i = 1:length_x
    if sum(sum(judge(i,:,:))) ==0
        continue
    else
        x_1 = i;
        break;
    end
end
for i = length_x:-1:1
    if sum(sum(judge(i,:,:))) ==0
        continue
    else
        x_2 = i;
        break;
    end
end
for i = 1:length_y
    if sum(sum(judge(:,i,:))) ==0
        continue
    else
        y_1 = i;
        break;
    end
end
for i = length_y:-1:1
    if sum(sum(judge(:,i,:))) ==0
        continue
    else
        y_2 = i;
        break;
    end
end
for i = 1:length_z
    if sum(sum(judge(:,:,i))) ==0
        continue
    else
        z_1 = i;
        break;
    end
end
for i = length_z:-1:1
    if sum(sum(judge(:,:,i))) ==0
        continue
    else
        z_2 = i;
        break;
    end
end

length_x = x_2 - x_1 +1;
length_y = y_2 - y_1 +1;
length_z = z_2 - z_1 +1;
zero = zeros(length_x,length_y,length_z);
temp = judge(x_1:x_2,y_1:y_2,z_1:z_2);
judge = temp;
temp = judge_in(x_1:x_2,y_1:y_2,z_1:z_2);
judge_in = temp;
temp = judge_in_left(x_1:x_2,y_1:y_2,z_1:z_2);
judge_in_left = temp;
temp = judge_in_right(x_1:x_2,y_1:y_2,z_1:z_2);
judge_in_right = temp;
temp = judge_mid(x_1:x_2,y_1:y_2,z_1:z_2);
judge_mid = temp;
temp = judge_out(x_1:x_2,y_1:y_2,z_1:z_2);
judge_out = temp;
temp = judge_pky(x_1:x_2,y_1:y_2,z_1:z_2);
judge_pky = temp;
temp = judge_pky_left(x_1:x_2,y_1:y_2,z_1:z_2);
judge_pky_left = temp;
temp = judge_pky_right(x_1:x_2,y_1:y_2,z_1:z_2);
judge_pky_right = temp;
temp = judge_p(x_1:x_2,y_1:y_2,z_1:z_2,:);
judge_p = temp;
end

