function value_ap = ap_set_5(ap_mode,ap_k,zoom_k,leng)
% generate APs of 5 layers of heart wall, the shape features come from the Grandi model,
% and the value feature come from Glukhov's in vitro heart experiment
k_ap_k = [290/271 290/271  260/216 260/216  240/192];
rest_ill_3 = -70;
ti = 2;
% nor
spline_o_0 = [-90 -90 24 2 6 8 8 7 6 4 1 -3 -10 -18 -28 -40 -55 -70 -80 -87 -89 -90 -90 -90 -90 -90 -90 -90 -90 -90 -90];
spline_m_0 = [-90 -90 26 5 8 9 9 9 8 7 6 5 3 0 -3 -6 -10 -15 -20 -27 -36 -48 -61 -74 -83 -88 -90 -90 -90 -90 -90];
spline_i_0 = [-90 -90 28 15 14 13 11.5 10 7 5 2 -2 -6 -12 -19 -28 -37 -48 -60 -73 -83 -88 -89 -90 -90 -90 -90 -90 -90 -90 -90 ];

spline_i_0_1 = spline_i_0;
spline_m_0_2 = spline_m_0;
spline_m_0_3 = spline_m_0;
spline_o_0_4 = spline_o_0;
spline_o_0_5 = spline_o_0;

% isc
spline_o_1 = [-80 -80 24 2 -1 -4 -7.5 -10 -14 -18 -22 -27 -34 -42 -52 -62 -70 -75 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80]; % epi
spline_m_1 = [-80 -80 25 10 9 7 5 3 0 -3 -6 -10 -15 -20 -28 -35 -43 -53 -62 -70 -77 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80]; % m
spline_i_1 = [-80 -80 28 15 12 8 5 2 -3 -8 -14 -20 -26 -32 -41 -50 -64 -75 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80 -80]; % endo

spline_i_1_1 = spline_i_1;
spline_m_1_2 = spline_m_1;
spline_m_1_3 = spline_m_1;
spline_o_1_4 = spline_o_1;
spline_o_1_5 = spline_o_1;

% 损伤
spline_o_2 = [-70 -70 24 3 -10 -30 -60 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70]; % 心室外膜损伤
spline_m_2 = [-70 -70 25 10 5 -2 -14 -33 -55 -65 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70]; % 心室M损伤
spline_i_2 = [-70 -70 28 15 0 -15 -35 -58 -68 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70 -70]; % 心室内膜损伤

spline_i_2_1 = spline_i_2;
spline_m_2_2 = spline_m_2;
spline_m_2_3 = spline_m_2;
spline_o_2_4 = spline_o_2;
spline_o_2_5 = spline_o_2;



value_ventricle_out_1 = spline_o_0_4;
value_ventricle_out_t = zeros(1,54);
value_ventricle_out_t(1:8) = value_ventricle_out_1(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_1(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_1(9:end))/2;
temp_out_1 = ap_k(1)*7*ti*k_ap_k(1);  % 这个参数是仿照别人的APD去调的
value_ventricle_out_1 = interp1(1:temp_out_1:54*temp_out_1,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_out_2 = spline_o_0_5;
value_ventricle_out_t = zeros(1,54);
value_ventricle_out_t(1:8) = value_ventricle_out_2(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_2(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_2(9:end))/2;
temp_out_2 = ap_k(2)*7*ti*k_ap_k(2);  % 
value_ventricle_out_2 = interp1(1:temp_out_2:54*temp_out_2,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_mid_1 = spline_m_0_2;
value_ventricle_mid_t = zeros(1,54);
value_ventricle_mid_t(1:8) = value_ventricle_mid_1(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_1(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_1(9:end))/2;
temp_mid_1 = ap_k(3)*7*ti*k_ap_k(3);
value_ventricle_mid_1 = interp1(1:temp_mid_1:54*temp_mid_1,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_mid_2 = spline_m_0_3;
value_ventricle_mid_t = zeros(1,54);
value_ventricle_mid_t(1:8) = value_ventricle_mid_2(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_2(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_2(9:end))/2;
temp_mid_2 = ap_k(4)*7*ti*k_ap_k(4);
value_ventricle_mid_2 = interp1(1:temp_mid_2:54*temp_mid_2,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_in = spline_i_0_1;
value_ventricle_out_t = zeros(1,54);
value_ventricle_out_t(1:8) = value_ventricle_in(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_in(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_in(9:end))/2;
temp_in = ap_k(5)*7*ti*k_ap_k(5);
value_ventricle_in = interp1(1:temp_in:54*temp_in,value_ventricle_out_t,1:54*7*ti,'pchip');

%% abnormal AP
% isc
value_ventricle_out_ill_1_1 = spline_o_1_4; % 
value_ventricle_out_t(1:8) = value_ventricle_out_ill_1_1(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_ill_1_1(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_ill_1_1(9:end))/2;
value_ventricle_out_ill_1_1 = interp1(1:temp_out_1:54*temp_out_1,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_out_ill_1_2 = spline_o_1_5;
value_ventricle_out_t(1:8) = value_ventricle_out_ill_1_2(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_ill_1_2(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_ill_1_2(9:end))/2;
value_ventricle_out_ill_1_2 = interp1(1:temp_out_2:54*temp_out_2,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_mid_ill_1_1 = spline_m_1_2;
value_ventricle_mid_t(1:8) = value_ventricle_mid_ill_1_1(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_ill_1_1(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_ill_1_1(9:end))/2;
value_ventricle_mid_ill_1_1 = interp1(1:temp_mid_1:54*temp_mid_1,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_mid_ill_1_2 = spline_m_1_3;
value_ventricle_mid_t(1:8) = value_ventricle_mid_ill_1_2(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_ill_1_2(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_ill_1_2(9:end))/2;
value_ventricle_mid_ill_1_2 = interp1(1:temp_mid_2:54*temp_mid_2,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_in_ill_1 = spline_i_1_1;
value_ventricle_in_t(1:8) = value_ventricle_in_ill_1(1:8);
value_ventricle_in_t(10:2:54) = value_ventricle_in_ill_1(9:end);
value_ventricle_in_t(9:2:54) = (value_ventricle_in_t(8:2:53) + value_ventricle_in_ill_1(9:end))/2;
value_ventricle_in_ill_1 = interp1(1:temp_in:54*temp_in,value_ventricle_in_t,1:54*7*ti,'pchip');


%% inj
value_ventricle_out_ill_2_1 = spline_o_2_4;
value_ventricle_out_t(1:8) = value_ventricle_out_ill_2_1(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_ill_2_1(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_ill_2_1(9:end))/2;
value_ventricle_out_ill_2_1 = interp1(1:temp_out_1:54*temp_out_1,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_out_ill_2_2 = spline_o_2_5;
value_ventricle_out_t(1:8) = value_ventricle_out_ill_2_2(1:8);
value_ventricle_out_t(10:2:54) = value_ventricle_out_ill_2_2(9:end);
value_ventricle_out_t(9:2:54) = (value_ventricle_out_t(8:2:53) + value_ventricle_out_ill_2_2(9:end))/2;
value_ventricle_out_ill_2_2 = interp1(1:temp_out_2:54*temp_out_2,value_ventricle_out_t,1:54*7*ti,'pchip');

value_ventricle_mid_ill_2_1 = spline_m_2_2;
value_ventricle_mid_t(1:8) = value_ventricle_mid_ill_2_1(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_ill_2_1(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_ill_2_1(9:end))/2;
value_ventricle_mid_ill_2_1 = interp1(1:temp_mid_1:54*temp_mid_1,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_mid_ill_2_2 = spline_m_2_3;
value_ventricle_mid_t(1:8) = value_ventricle_mid_ill_2_2(1:8);
value_ventricle_mid_t(10:2:54) = value_ventricle_mid_ill_2_2(9:end);
value_ventricle_mid_t(9:2:54) = (value_ventricle_mid_t(8:2:53) + value_ventricle_mid_ill_2_2(9:end))/2;
value_ventricle_mid_ill_2_2 = interp1(1:temp_mid_2:54*temp_mid_2,value_ventricle_mid_t,1:54*7*ti,'pchip');

value_ventricle_in_ill_2 = spline_i_2_1;
value_ventricle_in_t(1:8) = value_ventricle_in_ill_2(1:8);
value_ventricle_in_t(10:2:54) = value_ventricle_in_ill_2(9:end);
value_ventricle_in_t(9:2:54) = (value_ventricle_in_t(8:2:53) + value_ventricle_in_ill_2(9:end))/2;
value_ventricle_in_ill_2 = interp1(1:temp_in:54*temp_in,value_ventricle_in_t,1:54*7*ti,'pchip');

if ap_mode == 1
    mt = find(value_ventricle_out_1 == max(value_ventricle_out_1));
    value_ventricle_out_1(1:mt) = [-90*ones(1,mt-1) 24];
    mt = find(value_ventricle_out_2 == max(value_ventricle_out_2));
    value_ventricle_out_2(1:mt) = [-90*ones(1,mt-1) 24];
    mt = find(value_ventricle_mid_1 == max(value_ventricle_mid_1));
    value_ventricle_mid_1(1:mt) = [-90*ones(1,mt-1) 26];
    mt = find(value_ventricle_mid_2 == max(value_ventricle_mid_2));
    value_ventricle_mid_2(1:mt) = [-90*ones(1,mt-1) 26];
    mt = find(value_ventricle_in == max(value_ventricle_in));
    value_ventricle_in(1:mt) = [-90*ones(1,mt-1) 28];
    
    value_ventricle_out_ill_1_1(1:mt) = [-80*ones(1,mt-1) 24];
    value_ventricle_out_ill_1_2(1:mt) = [-80*ones(1,mt-1) 24];
    value_ventricle_mid_ill_1_1(1:mt) = [-80*ones(1,mt-1) 25];
    value_ventricle_mid_ill_1_2(1:mt) = [-80*ones(1,mt-1) 25];
    value_ventricle_in_ill_1(1:mt) = [-80*ones(1,mt-1) 28];
    
    value_ventricle_out_ill_2_1(1:mt) = [-70*ones(1,mt-1) 24];
    value_ventricle_out_ill_2_2(1:mt) = [-70*ones(1,mt-1) 24];
    value_ventricle_mid_ill_2_1(1:mt) = [-70*ones(1,mt-1) 25];
    value_ventricle_mid_ill_2_2(1:mt) = [-70*ones(1,mt-1) 25];
    value_ventricle_in_ill_2(1:mt) = [-70*ones(1,mt-1) 28];
end

value_ventricle_out_ill_3_1 = rest_ill_3*ones(1,378 *ti);
value_ventricle_out_ill_3_2 = rest_ill_3*ones(1,378 *ti);
value_ventricle_mid_ill_3_1 = rest_ill_3*ones(1,378 *ti);
value_ventricle_mid_ill_3_2 = rest_ill_3*ones(1,378 *ti);
value_ventricle_in_ill_3 = rest_ill_3*ones(1,378 *ti);

if 378 *ti < leng
    value_ventricle_out_1 = [value_ventricle_out_1 -90*ones(1,leng-378 *ti)];
    value_ventricle_out_2 = [value_ventricle_out_2 -90*ones(1,leng-378 *ti)];
    value_ventricle_mid_1 = [value_ventricle_mid_1 -90*ones(1,leng-378 *ti)];
    value_ventricle_mid_2 = [value_ventricle_mid_2 -90*ones(1,leng-378 *ti)];
    value_ventricle_in = [value_ventricle_in -90*ones(1,leng-378 *ti)];
    
    value_ventricle_out_ill_1_1 = [value_ventricle_out_ill_1_1 -80*ones(1,leng-378 *ti)];
    value_ventricle_out_ill_1_2 = [value_ventricle_out_ill_1_2 -80*ones(1,leng-378 *ti)];
    value_ventricle_mid_ill_1_1 = [value_ventricle_mid_ill_1_1 -80*ones(1,leng-378 *ti)];
    value_ventricle_mid_ill_1_2 = [value_ventricle_mid_ill_1_2 -80*ones(1,leng-378 *ti)];
    value_ventricle_in_ill_1 = [value_ventricle_in_ill_1 -80*ones(1,leng-378 *ti)];
    
    value_ventricle_out_ill_2_1 = [value_ventricle_out_ill_2_1 -70*ones(1,leng-378 *ti)];
    value_ventricle_out_ill_2_2 = [value_ventricle_out_ill_2_2 -70*ones(1,leng-378 *ti)];
    value_ventricle_mid_ill_2_1 = [value_ventricle_mid_ill_2_1 -70*ones(1,leng-378 *ti)];
    value_ventricle_mid_ill_2_2 = [value_ventricle_mid_ill_2_2 -70*ones(1,leng-378 *ti)];
    value_ventricle_in_ill_2 = [value_ventricle_in_ill_2 -70*ones(1,leng-378 *ti)];
    
    value_ventricle_out_ill_3_1 = rest_ill_3*ones(1,leng);
    value_ventricle_out_ill_3_2 = rest_ill_3*ones(1,leng);
    value_ventricle_mid_ill_3_1 = rest_ill_3*ones(1,leng);
    value_ventricle_mid_ill_3_2 = rest_ill_3*ones(1,leng);
    value_ventricle_in_ill_3 = rest_ill_3*ones(1,leng);
    
end

value_ventricle_out_1 = Y_zoom(value_ventricle_out_1,zoom_k(1,:));
value_ventricle_out_2 = Y_zoom(value_ventricle_out_2,zoom_k(1,:));
value_ventricle_mid_1 = Y_zoom(value_ventricle_mid_1,zoom_k(1,:));
value_ventricle_mid_2 = Y_zoom(value_ventricle_mid_2,zoom_k(1,:));
value_ventricle_in = Y_zoom(value_ventricle_in,zoom_k(1,:));

value_ventricle_out_ill_1_1 = Y_zoom(value_ventricle_out_ill_1_1,zoom_k(2,:));
value_ventricle_out_ill_1_2 = Y_zoom(value_ventricle_out_ill_1_2,zoom_k(2,:));
value_ventricle_mid_ill_1_1 = Y_zoom(value_ventricle_mid_ill_1_1,zoom_k(2,:));
value_ventricle_mid_ill_1_2 = Y_zoom(value_ventricle_mid_ill_1_2,zoom_k(2,:));
value_ventricle_in_ill_1 = Y_zoom(value_ventricle_in_ill_1,zoom_k(2,:));

value_ventricle_out_ill_2_1 = Y_zoom(value_ventricle_out_ill_2_1,zoom_k(3,:));
value_ventricle_out_ill_2_2 = Y_zoom(value_ventricle_out_ill_2_2,zoom_k(3,:));
value_ventricle_mid_ill_2_1 = Y_zoom(value_ventricle_mid_ill_2_1,zoom_k(3,:));
value_ventricle_mid_ill_2_2 = Y_zoom(value_ventricle_mid_ill_2_2,zoom_k(3,:));
value_ventricle_in_ill_2 = Y_zoom(value_ventricle_in_ill_2,zoom_k(3,:));

value_ap = [value_ventricle_out_1;value_ventricle_out_2;
    value_ventricle_out_ill_1_1;value_ventricle_out_ill_1_2; % isc
    value_ventricle_out_ill_2_1;value_ventricle_out_ill_2_2; % inj
    value_ventricle_out_ill_3_1;value_ventricle_out_ill_3_2; % inf
    
    value_ventricle_mid_1;value_ventricle_mid_2;     % 9
    value_ventricle_mid_ill_1_1;value_ventricle_mid_ill_1_2;
    value_ventricle_mid_ill_2_1;value_ventricle_mid_ill_2_2;
    value_ventricle_mid_ill_3_1;value_ventricle_mid_ill_3_2;
    
    value_ventricle_in;    % 17
    value_ventricle_in_ill_1;
    value_ventricle_in_ill_2;
    value_ventricle_in_ill_3];
end