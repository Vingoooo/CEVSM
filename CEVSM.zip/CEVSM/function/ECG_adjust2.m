function ECG_p3 = ECG_adjust2(ECG_p)
[N,~] = size(ECG_p);
    ECG_p3 = ECG_p;
    begina = ECG_p(:,100);
    enda = ECG_p(:,799); % 
    ECG_p3(:,1:100) = repmat( begina,1,100);
    ECG_p3(:,800) = enda;

end

