function ECG_p3 = ECG_adjust(ECG_p,x_t)
if x_t >= 0
    ECG_p2 = ECG_p;
    ECG_p3 = ECG_p;
    [N,T] = size(ECG_p);
    a = ECG_p(:,800); % 50ms
    ECG_p2 = ECG_p - a;
    ECG_p3(:,1:T-x_t) = ECG_p2(:,x_t+1:T);
    ECG_p3(:,T-x_t:T) = ECG_p2(:,T-x_t-2:T-2);
else
    ECG_p2 = ECG_p;
    ECG_p3 = ECG_p;
    [N,T] = size(ECG_p);
    a = ECG_p(:,1); % 50ms
    ECG_p2 = ECG_p - a;
    ECG_p3(:,-x_t:T) = ECG_p2(:,1:T+x_t+1);
    ECG_p3(:,1:-x_t) = 0;
end
end

